// يشتغل محلياً وعلى GitHub أثناء البناء:
// 1) يحوّل www/questions.js إلى www/questions.json
// 2) على GitHub: يحط رابط الأسئلة الأونلاين واسم المستودع لوحده
// 3) على GitHub: يقرأ firebase-db-url.txt (لو موجود) ويفعّل "واحد ضد واحد"
// 4) على GitHub: يثبّت مفتاح توقيع ثابت عشان التحديثات تتثبّت فوق النسخة القديمة
const fs = require("fs"), path = require("path"), os = require("os");
const root = path.join(__dirname, "..");
global.window = {};
require(path.join(root, "www/questions.js"));
const q = window.BUNDLED_QUESTIONS;
fs.writeFileSync(path.join(root, "www/questions.json"), JSON.stringify(q));
console.log("تم: " + q.length + " سؤال");

const cfgPath = path.join(root, "www/config.js");
let cfg = fs.readFileSync(cfgPath, "utf8");
const repo = process.env.GITHUB_REPOSITORY;
if (repo) {
  cfg = cfg.replace("USERNAME/REPO", repo);
  console.log("رابط الأسئلة الأونلاين: " + repo);
}
for (const f of ["firebase-db-url.txt", "../firebase-db-url.txt"]) {
  const fp = path.join(root, f);
  if (fs.existsSync(fp)) {
    const url = fs.readFileSync(fp, "utf8").trim().replace(/[\s"']/g, "");
    if (/^https:\/\/[\w.-]+/.test(url)) { cfg = cfg.replace('FIREBASE_DB: ""', 'FIREBASE_DB: "' + url + '"'); console.log("تم تفعيل واحد ضد واحد: " + url); break; }
  }
}
fs.writeFileSync(cfgPath, cfg);

const ks = path.join(root, "assets/debug.keystore");
if (process.env.CI && fs.existsSync(ks)) {
  const dir = path.join(os.homedir(), ".android");
  fs.mkdirSync(dir, { recursive: true });
  fs.copyFileSync(ks, path.join(dir, "debug.keystore"));
  console.log("تم تثبيت مفتاح التوقيع الثابت");
}
